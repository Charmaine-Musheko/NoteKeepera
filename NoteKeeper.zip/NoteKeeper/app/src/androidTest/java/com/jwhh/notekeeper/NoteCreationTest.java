package com.jwhh.notekeeper;

import android.support.test.runner.AndroidJUnit4;

import com.example.notekeeper.NoteListActivity;

import org.junit.Rule;
import org.junit.runner.RunWith;

import static org.junit.Assert.*;

@RunWith(AndroidJUnit4.class)
public class NoteCreationTest {
    @Rule
    public ActivityTestRule<NoteListActivity> mNoteListActivityRule =
            new ActivityTestRule<>(NoteListActivity.class);


    }